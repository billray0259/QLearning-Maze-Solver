# QLearning-Maze-Solver
My first attempt at a QLearning algorithm

It takes a while for the agent to find the goal initially. If space is pressed while the maze window is in focus it will speed the agent up. Press space again to slow the agent back down.
