
public enum Action {
	UP, DOWN, LEFT, RIGHT;
}
